import courses from "./courses.json";
export default {
  courses,
};
